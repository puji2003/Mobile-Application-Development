package com.example.dogfoodapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ManageUsersActivity extends AppCompatActivity {

    private ListView listViewUsers;
    private Button btnAddUser;
    private UserDatabaseHelper userDatabaseHelper;
    private ArrayList<String> userList;
    private ArrayAdapter<String> userAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_users);

        listViewUsers = findViewById(R.id.listViewUsers);
        btnAddUser = findViewById(R.id.btnAddUser);
        userDatabaseHelper = new UserDatabaseHelper(this);
        userList = new ArrayList<>();

        // Load users into the list
        loadUsers();

        btnAddUser.setOnClickListener(v -> {
            Intent intent = new Intent(ManageUsersActivity.this, AddUserActivity.class);
            startActivityForResult(intent, 1);
        });

        listViewUsers.setOnItemClickListener((parent, view, position, id) -> {
            String userEmail = userList.get(position);
            Intent intent = new Intent(ManageUsersActivity.this, EditUserActivity.class);
            intent.putExtra("EMAIL", userEmail);
            startActivityForResult(intent, 2);
        });
    }

    private void loadUsers() {
        userList.clear();
        Cursor cursor = userDatabaseHelper.getAllUsers();
        while (cursor.moveToNext()) {
            String email = cursor.getString(cursor.getColumnIndex("email"));
            userList.add(email);
        }
        cursor.close();

        userAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userList);
        listViewUsers.setAdapter(userAdapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 || requestCode == 2) {
            loadUsers();
        }
    }
}
