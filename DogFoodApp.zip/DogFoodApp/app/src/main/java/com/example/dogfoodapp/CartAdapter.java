package com.example.dogfoodapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<Product> cartProductList;
    private CartDatabaseHelper cartDatabaseHelper;
    private OnProductRemoveListener onProductRemoveListener;

    public CartAdapter(List<Product> cartProductList, CartDatabaseHelper cartDatabaseHelper, OnProductRemoveListener onProductRemoveListener) {
        this.cartProductList = cartProductList;
        this.cartDatabaseHelper = cartDatabaseHelper;
        this.onProductRemoveListener = onProductRemoveListener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart_product, parent, false);
        return new CartViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        Product currentProduct = cartProductList.get(position);
        holder.textViewName.setText(currentProduct.getName());
        holder.textViewDescription.setText(currentProduct.getDescription());
        holder.textViewPrice.setText(String.valueOf(currentProduct.getPrice()));
        holder.imageViewProduct.setImageResource(currentProduct.getImageResId());

        // Remove item button action
        holder.imageButtonRemove.setOnClickListener(v -> {
            // Remove item from the database
            cartDatabaseHelper.removeProductFromCart(currentProduct);
            // Remove item from the list and notify adapter
            cartProductList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, cartProductList.size());

            // Notify the CartActivity to update the total price
            if (onProductRemoveListener != null) {
                onProductRemoveListener.onProductRemoved();
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartProductList.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewName, textViewDescription, textViewPrice;
        public ImageView imageViewProduct;
        public ImageButton imageButtonRemove; // Remove button

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_cart_name);
            textViewDescription = itemView.findViewById(R.id.text_view_cart_description);
            textViewPrice = itemView.findViewById(R.id.text_view_cart_price);
            imageViewProduct = itemView.findViewById(R.id.image_view_cart_product);
            imageButtonRemove = itemView.findViewById(R.id.image_button_remove); // Initialize remove button
        }
    }

    // Interface to notify when a product is removed
    public interface OnProductRemoveListener {
        void onProductRemoved();
    }
}
