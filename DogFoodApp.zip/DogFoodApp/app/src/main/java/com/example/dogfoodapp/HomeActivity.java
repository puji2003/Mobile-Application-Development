// HomeActivity.java
package com.example.dogfoodapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private ViewPager reviewViewPager;
    private RecyclerView featuredProductsRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        reviewViewPager = findViewById(R.id.reviewViewPager);
        featuredProductsRecyclerView = findViewById(R.id.featuredProductsRecyclerView);

        // Dummy reviews
        List<Review> sampleReviews = new ArrayList<>();
        sampleReviews.add(new Review("Asela Wijesinghe", "My pup's energy has doubled since switching to this brand! Fantastic quality.", System.currentTimeMillis()));
        sampleReviews.add(new Review("Sajani Rodrigo", "I've never seen my dog so excited for mealtime. Amazing food!", System.currentTimeMillis()));
        sampleReviews.add(new Review("Ruwan Jayasinghe", "Excellent choice! My dog’s coat looks shinier and healthier.", System.currentTimeMillis()));
        sampleReviews.add(new Review("Tharindi Gunasekara", "Finally found a dog food that agrees with my pet's sensitive stomach.", System.currentTimeMillis()));
        sampleReviews.add(new Review("Lahiru Mendis", "Impressed with the ingredients and quality. Highly recommended for all dog owners!", System.currentTimeMillis()));
        sampleReviews.add(new Review("Dilini Karunaratne", "It's been a game-changer! My dog is more active and happy now.", System.currentTimeMillis()));

        // Set up the ViewPager for reviews
        ReviewPagerAdapter reviewPagerAdapter = new ReviewPagerAdapter(this, sampleReviews);
        reviewViewPager.setAdapter(reviewPagerAdapter);
        reviewViewPager.setPageTransformer(true, new DepthPageTransformer());

        // Setup featured products
        setupFeaturedProducts();

        // Initialize Bottom Navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.btnProductCatalog) {
                    startActivity(new Intent(HomeActivity.this, ProductListActivity.class));
                    return true;
                } else if (item.getItemId() == R.id.btnShoppingCart) {
                    startActivity(new Intent(HomeActivity.this, CartActivity.class));
                    return true;
                } else if (item.getItemId() == R.id.btnEducationalContent) {
                    startActivity(new Intent(HomeActivity.this, EducationalContent.class));
                    return true;
                } else if (item.getItemId() == R.id.btnProfile) {
                    startActivity(new Intent(HomeActivity.this, ProfileActivity.class));
                    return true;
                } else if (item.getItemId() == R.id.btnOrderList) {
                    startActivity(new Intent(HomeActivity.this, OrderListActivity.class));
                    return true;
                }
                return false;
            }
        });
    }

    private void setupFeaturedProducts() {
        // Dummy featured products
        List<FeaturedProduct> featuredProducts = new ArrayList<>();
        featuredProducts.add(new FeaturedProduct("Organic Dog Biscuits", "Crunchy, all-natural biscuits perfect for sensitive stomachs.", R.drawable.organic_biscuits));
        featuredProducts.add(new FeaturedProduct("Smart Feeder", "Automatic feeder with portion control for a healthier diet.", R.drawable.smart_feeder));
        featuredProducts.add(new FeaturedProduct("Cooling Dog Mat", "Keep your pet comfortable on hot days with this cooling mat.", R.drawable.cooling_mat));
        featuredProducts.add(new FeaturedProduct("Eco-Friendly Dog Shampoo", "Gentle and eco-conscious shampoo for a shiny coat.", R.drawable.eco_shampoo));
        featuredProducts.add(new FeaturedProduct("High-Protein Meal Pack", "Specially formulated for active and energetic dogs.", R.drawable.high_protein_meal));
        featuredProducts.add(new FeaturedProduct("Adjustable Harness", "Comfortable and secure harness for walks of any length.", R.drawable.adjustable_harness));


        // Set up the RecyclerView for featured products
        featuredProductsRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        FeaturedProductsAdapter featuredProductsAdapter = new FeaturedProductsAdapter(featuredProducts, this);
        featuredProductsRecyclerView.setAdapter(featuredProductsAdapter);
    }
}
