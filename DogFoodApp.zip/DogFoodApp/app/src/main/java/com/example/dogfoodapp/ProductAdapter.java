// ProductAdapter.java
package com.example.dogfoodapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private List<Product> productList;
    private List<Product> productListFull;
    private Context context;
    private CartDatabaseHelper cartDatabaseHelper;

    public ProductAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
        productListFull = new ArrayList<>(productList);
        cartDatabaseHelper = new CartDatabaseHelper(context);
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product currentProduct = productList.get(position);
        holder.textViewName.setText(currentProduct.getName());
        holder.textViewDescription.setText(currentProduct.getDescription());
        holder.textViewPrice.setText(String.valueOf(currentProduct.getPrice()));

        // Load drawable resource into ImageView
        holder.imageViewProduct.setImageResource(currentProduct.getImageResId());

        holder.buttonAddToCart.setOnClickListener(v -> {
            cartDatabaseHelper.addProductToCart(currentProduct);
            Toast.makeText(context, "Added to Cart", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewName, textViewDescription, textViewPrice;
        public ImageView imageViewProduct;
        public Button buttonAddToCart;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.text_view_name);
            textViewDescription = itemView.findViewById(R.id.text_view_description);
            textViewPrice = itemView.findViewById(R.id.text_view_price);
            imageViewProduct = itemView.findViewById(R.id.image_view_product);
            buttonAddToCart = itemView.findViewById(R.id.button_add_to_cart);
        }
    }

    public void updateList(List<Product> newList) {
        productList = new ArrayList<>(newList);
        productListFull = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    public android.widget.Filter getFilter() {
        return new android.widget.Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                List<Product> filteredList = new ArrayList<>();
                if (constraint == null || constraint.length() == 0) {
                    filteredList.addAll(productListFull);
                } else {
                    String filterPattern = constraint.toString().toLowerCase().trim();
                    for (Product item : productListFull) {
                        if (item.getName().toLowerCase().contains(filterPattern)) {
                            filteredList.add(item);
                        }
                    }
                }
                FilterResults results = new FilterResults();
                results.values = filteredList;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                productList.clear();
                productList.addAll((List) results.values);
                notifyDataSetChanged();
            }
        };
    }
}
