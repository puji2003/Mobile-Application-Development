// OrderAdapter.java
package com.example.dogfoodapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;

    public OrderAdapter(List<Order> orderList) {
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order currentOrder = orderList.get(position);
        holder.textViewProductName.setText(currentOrder.getProductName());
        holder.textViewPrice.setText(String.format("Rs%.2f", currentOrder.getPrice()));
        holder.textViewOrderDate.setText(currentOrder.getOrderDate());
        holder.textViewOrderStatus.setText(currentOrder.getStatus()); // Set status
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewProductName, textViewPrice, textViewOrderDate, textViewOrderStatus;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewProductName = itemView.findViewById(R.id.text_view_order_name);
            textViewPrice = itemView.findViewById(R.id.text_view_order_price);
            textViewOrderDate = itemView.findViewById(R.id.text_view_order_date);
            textViewOrderStatus = itemView.findViewById(R.id.text_view_order_status); // Initialize status TextView
        }
    }
}
