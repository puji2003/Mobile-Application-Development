package com.example.dogfoodapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class EducationalContent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_educational_content);

        // Set OnClickListener for Articles Card
        findViewById(R.id.cardViewOne).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirect to EducationHubActivity for Articles
                Intent intent = new Intent(EducationalContent.this, EducationHubActivity.class);
                startActivity(intent);
            }
        });
    }

    public void redirectEducationVideo(View view) {
        Intent intent = new Intent(getApplicationContext(), EducationalVideo.class);
        startActivity(intent);
    }
}
