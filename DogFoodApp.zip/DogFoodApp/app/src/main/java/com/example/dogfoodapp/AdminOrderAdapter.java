// AdminOrderAdapter.java
package com.example.dogfoodapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AdminOrderAdapter extends RecyclerView.Adapter<AdminOrderAdapter.OrderViewHolder> {

    private List<Order> orderList;
    private OrderDatabaseHelper orderDatabaseHelper;

    public AdminOrderAdapter(List<Order> orderList, OrderDatabaseHelper orderDatabaseHelper) {
        this.orderList = orderList;
        this.orderDatabaseHelper = orderDatabaseHelper;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_admin, parent, false);
        return new OrderViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order currentOrder = orderList.get(position);
        holder.textViewProductName.setText(currentOrder.getProductName());
        holder.textViewPrice.setText(String.valueOf(currentOrder.getPrice()));
        holder.textViewOrderDate.setText(currentOrder.getOrderDate());
        holder.textViewStatus.setText(currentOrder.getStatus());

        // Set up buttons for status updates
        holder.btnPending.setOnClickListener(v -> updateOrderStatus(currentOrder, Order.STATUS_PENDING));
        holder.btnConfirmed.setOnClickListener(v -> updateOrderStatus(currentOrder, Order.STATUS_CONFIRMED));
        holder.btnCancelled.setOnClickListener(v -> updateOrderStatus(currentOrder, Order.STATUS_CANCELLED));
    }

    private void updateOrderStatus(Order order, String status) {
        orderDatabaseHelper.updateOrderStatus(order.getId(), status);
        orderList.clear();
        orderList.addAll(orderDatabaseHelper.getAllOrders()); // Refresh the list
        notifyDataSetChanged(); // Update UI
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewProductName, textViewPrice, textViewOrderDate, textViewStatus;
        public Button btnPending, btnConfirmed, btnCancelled;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewProductName = itemView.findViewById(R.id.text_view_order_name);
            textViewPrice = itemView.findViewById(R.id.text_view_order_price);
            textViewOrderDate = itemView.findViewById(R.id.text_view_order_date);
            textViewStatus = itemView.findViewById(R.id.text_view_order_status);
            btnPending = itemView.findViewById(R.id.btnPending);
            btnConfirmed = itemView.findViewById(R.id.btnConfirmed);
            btnCancelled = itemView.findViewById(R.id.btnCancelled);
        }
    }
}
