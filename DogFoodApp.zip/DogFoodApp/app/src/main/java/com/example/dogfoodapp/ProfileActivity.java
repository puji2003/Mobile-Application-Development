package com.example.dogfoodapp;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    private EditText profileEmail, profileName, profileAddress;
    private Button updateProfileButton;
    private UserDatabaseHelper userDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profileEmail = findViewById(R.id.profile_email);
        profileName = findViewById(R.id.profile_name);
        profileAddress = findViewById(R.id.profile_address);
        updateProfileButton = findViewById(R.id.update_profile_button);

        userDatabaseHelper = new UserDatabaseHelper(this);

        loadUserProfile();

        updateProfileButton.setOnClickListener(v -> updateUserProfile());
    }

    private void loadUserProfile() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String email = sharedPreferences.getString("email", "");

        Cursor cursor = userDatabaseHelper.getUserData(email);
        if (cursor != null && cursor.moveToFirst()) {
            profileEmail.setText(cursor.getString(cursor.getColumnIndex("email")));
            profileName.setText(cursor.getString(cursor.getColumnIndex("name")));
            profileAddress.setText(cursor.getString(cursor.getColumnIndex("address")));
            cursor.close();
        }
    }

    private void updateUserProfile() {
        String email = profileEmail.getText().toString().trim();
        String name = profileName.getText().toString().trim();
        String address = profileAddress.getText().toString().trim();

        if (name.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isUpdated = userDatabaseHelper.updateUserData(email, name, address);
        if (isUpdated) {
            Toast.makeText(this, "Profile Updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Profile Update Failed", Toast.LENGTH_SHORT).show();
        }
    }
}
