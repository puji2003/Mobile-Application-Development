package com.example.dogfoodapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EducationHubActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EducationAdapter educationAdapter;
    private List<EducationContent> educationContentList;
    private EducationDatabaseHelper educationDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education_hub);

        recyclerView = findViewById(R.id.recycler_view_education);
        educationDatabaseHelper = new EducationDatabaseHelper(this);

        // Insert new educational content into the database
        insertSampleData();

        educationContentList = educationDatabaseHelper.getAllEducationContent();
        educationAdapter = new EducationAdapter(educationContentList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(educationAdapter);
    }

    private void insertSampleData() {
        educationDatabaseHelper.insertEducationContent(new EducationContent(
                "Dog Breeds: German Shepherd",
                "German Shepherds are highly intelligent, loyal, and versatile working dogs. They excel in various roles including police work, search and rescue, and as loyal family pets."
        ));

        educationDatabaseHelper.insertEducationContent(new EducationContent(
                "Dog Breeds: Golden Retriever",
                "Golden Retrievers are known for their friendly, tolerant attitude. They are great family pets and are highly trainable, making them ideal for service work."
        ));

        educationDatabaseHelper.insertEducationContent(new EducationContent(
                "Nutrition: Protein for Dogs",
                "Protein is essential for dogs, aiding in muscle growth, repair, and immune function. Good sources include meat, eggs, and fish."
        ));

        educationDatabaseHelper.insertEducationContent(new EducationContent(
                "Nutrition: Vitamins and Minerals",
                "Vitamins and minerals support various functions like bone health, coat quality, and vision. A balanced diet often covers these needs."
        ));

        educationDatabaseHelper.insertEducationContent(new EducationContent(
                "Life Stages: Puppy",
                "Puppies require a high-calorie diet to support growth and development. Socialization and basic training are crucial during this stage."
        ));

        educationDatabaseHelper.insertEducationContent(new EducationContent(
                "Life Stages: Adult Dog",
                "Adult dogs need a balanced diet and regular exercise to maintain health. Monitoring their weight and activity level is important."
        ));

        educationDatabaseHelper.insertEducationContent(new EducationContent(
                "Health: Common Health Issues",
                "Dogs may experience issues like dental disease, arthritis, and allergies. Regular vet visits help in early detection and management."
        ));
    }
}
