// Review.java
package com.example.dogfoodapp;

public class Review {
    private String userName;
    private String reviewText;
    private long timestamp; // Add a timestamp field

    // Updated constructor to accept three parameters
    public Review(String userName, String reviewText, long timestamp) {
        this.userName = userName;
        this.reviewText = reviewText;
        this.timestamp = timestamp; // Initialize the timestamp
    }

    public String getUserName() {
        return userName;
    }

    public String getReviewText() {
        return reviewText;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
