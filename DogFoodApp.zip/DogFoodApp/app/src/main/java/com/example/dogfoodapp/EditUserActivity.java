package com.example.dogfoodapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditUserActivity extends AppCompatActivity {

    private EditText etName, etAddress, etPassword;
    private Button btnUpdate, btnDelete;
    private UserDatabaseHelper userDatabaseHelper;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        etPassword = findViewById(R.id.etPassword);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);

        userDatabaseHelper = new UserDatabaseHelper(this);
        userEmail = getIntent().getStringExtra("EMAIL");

        // Load user data
        loadUserData();

        btnUpdate.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String address = etAddress.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (userDatabaseHelper.updateUserData(userEmail, name, address)) {
                Toast.makeText(EditUserActivity.this, "User updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(EditUserActivity.this, "Error updating user", Toast.LENGTH_SHORT).show();
            }
        });

        btnDelete.setOnClickListener(v -> {
            // Implement deletion logic
            if (userDatabaseHelper.deleteUser(userEmail)) {
                Toast.makeText(EditUserActivity.this, "User deleted successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(EditUserActivity.this, "Error deleting user", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadUserData() {
        Cursor cursor = userDatabaseHelper.getUserData(userEmail);
        if (cursor.moveToFirst()) {
            etName.setText(cursor.getString(cursor.getColumnIndex("name")));
            etAddress.setText(cursor.getString(cursor.getColumnIndex("address")));
            etPassword.setText(cursor.getString(cursor.getColumnIndex("password")));  // Optional to show password
        }
        cursor.close();
    }
}
