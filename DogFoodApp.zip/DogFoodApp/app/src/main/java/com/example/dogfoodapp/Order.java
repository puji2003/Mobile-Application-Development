// Order.java
package com.example.dogfoodapp;

public class Order {
    public static final String STATUS_PENDING = "Pending";
    public static final String STATUS_CANCELLED = "Cancelled";
    public static final String STATUS_CONFIRMED = "Confirmed";

    private int id;
    private String productName;
    private double price;
    private String orderDate;
    private String status;

    public Order(int id, String productName, double price, String orderDate, String status) {
        this.id = id;
        this.productName = productName;
        this.price = price;
        this.orderDate = orderDate;
        this.status = status;
    }

    // Constructor with default status
    public Order(int id, String productName, double price, String orderDate) {
        this(id, productName, price, orderDate, STATUS_PENDING);
    }

    // Getter methods
    public int getId() { return id; }
    public String getProductName() { return productName; }
    public double getPrice() { return price; }
    public String getOrderDate() { return orderDate; }
    public String getStatus() { return status; }
}
