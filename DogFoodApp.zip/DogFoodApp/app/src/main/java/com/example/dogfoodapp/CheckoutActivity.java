// CheckoutActivity.java
package com.example.dogfoodapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CheckoutActivity extends AppCompatActivity {

    private TextView tvTotalPrice;
    private Button btnPlaceOrder;
    private CartDatabaseHelper cartDatabaseHelper;
    private OrderDatabaseHelper orderDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        btnPlaceOrder = findViewById(R.id.btnPlaceOrder);
        cartDatabaseHelper = new CartDatabaseHelper(this);
        orderDatabaseHelper = new OrderDatabaseHelper(this);

        double totalPrice = getIntent().getDoubleExtra("totalPrice", 0.0);
        tvTotalPrice.setText(String.format("Total Price: Rs%.2f", totalPrice));

        btnPlaceOrder.setOnClickListener(v -> {
            v.animate().alpha(0.8f).setDuration(300).withEndAction(() -> {
                SharedPreferences sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
                String userEmail = sharedPreferences.getString("email", "");

                for (Product product : cartDatabaseHelper.getCartProducts()) {
                    String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                    Order order = new Order(0, product.getName(), product.getPrice(), currentDate);
                    orderDatabaseHelper.addOrder(order, userEmail);
                }

                cartDatabaseHelper.clearCart();
                Toast.makeText(CheckoutActivity.this, "Order Placed Successfully", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }
}
