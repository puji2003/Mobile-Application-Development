package com.example.dogfoodapp;

public class FeaturedProduct {
    private String name;
    private String description;
    private int imageUrl; // This should be the image resource ID

    public FeaturedProduct(String name, String description, int imageUrl) {
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageUrl() {
        return imageUrl;
    }
}
