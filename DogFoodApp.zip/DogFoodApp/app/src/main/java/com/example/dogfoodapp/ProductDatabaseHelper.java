package com.example.dogfoodapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class ProductDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "dogfood.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_PRODUCTS = "products";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_IMAGE_RES_ID = "image_res_id";

    public ProductDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PRODUCTS_TABLE = "CREATE TABLE " + TABLE_PRODUCTS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NAME + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_PRICE + " REAL,"
                + COLUMN_IMAGE_RES_ID + " INTEGER" + ")";
        db.execSQL(CREATE_PRODUCTS_TABLE);

        // Insert sample data
        insertSampleData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUCTS);
        onCreate(db);
    }

    private void insertSampleData(SQLiteDatabase db) {

        insertProduct(db, "Beef Bone Rawhide Chews", "Beef Bone Rawhide Chews Dog Treats 4Pack", 1300.00, R.drawable.df);
        insertProduct(db, "Black Hawk", "Black Hawk Adult Grain Free Beef Wet Dog Food", 850.00, R.drawable.bh);
        insertProduct(db, "Black Hawk Adult Grain", "Black Hawk Adult Grain Free Beef Wet Dog Food (12 x 400g)", 9180.00, R.drawable.bhh);
        insertProduct(db, "Josera Mini Deluxe", "High-quality Josera Mini Deluxe dog food.", 3000.00, R.drawable.josera_mini_deluxe);
        insertProduct(db, "Josi Dog Active", "Active dry dog food by Josera, 900g.", 1700.00, R.drawable.josi_dog_active);
        insertProduct(db, "Josera Young Star", "Josera Young Star dry dog food, 15Kg.", 3500.00, R.drawable.josera_young_star);
        insertProduct(db, "Josera Poultry Menu", "Josera Poultry Menu dry dog food, 15Kg.", 2500.00, R.drawable.josera_poultry_menu);
        insertProduct(db, "Josera Festival", "Josera Festival dog food.", 2750.00, R.drawable.josera_festival);
        insertProduct(db, "JosiDog Adult Sensitive", "JosiDog Adult Sensitive dog food.", 4800.00, R.drawable.josidog_adult_sensitive);
        insertProduct(db, "Josi dog Junior Sensitive", "Josi dog Junior Sensitive dog food.", 1800.00, R.drawable.josee);
        insertProduct(db, "Josera Mini well", "Josera Mini well dog food.", 29000.00, R.drawable.josera_mini_well);
    }

    private void insertProduct(SQLiteDatabase db, String name, String description, double price, int imageResId) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_PRICE, price);
        values.put(COLUMN_IMAGE_RES_ID, imageResId);
        db.insert(TABLE_PRODUCTS, null, values);
    }

    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_PRODUCTS, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
                String description = cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION));
                double price = cursor.getDouble(cursor.getColumnIndex(COLUMN_PRICE));
                int imageResId = cursor.getInt(cursor.getColumnIndex(COLUMN_IMAGE_RES_ID));

                Product product = new Product(name, description, price, imageResId);
                productList.add(product);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return productList;
    }
}
