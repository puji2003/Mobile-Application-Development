package com.example.dogfoodapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CartAdapter cartAdapter;
    private CartDatabaseHelper cartDatabaseHelper;
    private List<Product> cartProductList;
    private TextView textTotalPrice;
    private Button buttonCheckout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        recyclerView = findViewById(R.id.recycler_view_cart);
        textTotalPrice = findViewById(R.id.text_total_price);
        buttonCheckout = findViewById(R.id.button_checkout);

        cartDatabaseHelper = new CartDatabaseHelper(this);
        cartProductList = cartDatabaseHelper.getCartProducts();

        // Initialize adapter with OnProductRemoveListener
        cartAdapter = new CartAdapter(cartProductList, cartDatabaseHelper, this::updateTotalPrice);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(cartAdapter);

        // Calculate and display initial total price
        updateTotalPrice();

        // Checkout button action
        buttonCheckout.setOnClickListener(v -> {
            double totalPrice = calculateTotalPrice();
            Intent intent = new Intent(CartActivity.this, CheckoutActivity.class);
            intent.putExtra("totalPrice", totalPrice);
            startActivity(intent);
        });
    }

    private double calculateTotalPrice() {
        double totalPrice = 0.0;
        for (Product product : cartProductList) {
            totalPrice += product.getPrice();
        }
        return totalPrice;
    }

    private void updateTotalPrice() {
        double totalPrice = calculateTotalPrice();
        textTotalPrice.setText(String.format("Total: Rs%.2f", totalPrice));
    }
}
