package com.example.dogfoodapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private final Context context;
    private final List<User> userList;
    private final UserDatabaseHelper dbHelper;

    public UserAdapter(Context context, List<User> userList, UserDatabaseHelper dbHelper) {
        this.context = context;
        this.userList = userList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = userList.get(position);
        holder.textName.setText(user.getName());
        holder.textEmail.setText(user.getEmail());
        holder.textAddress.setText(user.getAddress());

        // Edit user
        holder.btnEdit.setOnClickListener(v -> editUser(user));

        // Delete user with confirmation
        holder.btnDelete.setOnClickListener(v -> new MaterialAlertDialogBuilder(context)
                .setTitle("Delete User")
                .setMessage("Are you sure you want to delete this user?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    dbHelper.deleteUser(user.getEmail());
                    userList.remove(position);
                    notifyItemRemoved(position);
                })
                .setNegativeButton("Cancel", null)
                .show());
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    private void editUser(User user) {
        // Display edit dialog to update user details
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView textName, textEmail, textAddress;
        ImageButton btnEdit, btnDelete;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textUserName);
            textEmail = itemView.findViewById(R.id.textUserEmail);
            textAddress = itemView.findViewById(R.id.textUserAddress);
            btnEdit = itemView.findViewById(R.id.btnEditUser);
            btnDelete = itemView.findViewById(R.id.btnDeleteUser);
        }
    }
}
