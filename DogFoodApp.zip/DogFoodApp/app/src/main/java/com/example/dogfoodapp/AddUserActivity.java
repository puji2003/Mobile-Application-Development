package com.example.dogfoodapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddUserActivity extends AppCompatActivity {

    private EditText etEmail, etName, etAddress, etPassword;
    private Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        etEmail = findViewById(R.id.etEmail);
        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        etPassword = findViewById(R.id.etPassword);
        btnAdd = findViewById(R.id.btnAdd);

        btnAdd.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String name = etName.getText().toString().trim();
            String address = etAddress.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || name.isEmpty() || address.isEmpty() || password.isEmpty()) {
                Toast.makeText(AddUserActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            UserDatabaseHelper userDatabaseHelper = new UserDatabaseHelper(AddUserActivity.this);
            boolean isInserted = userDatabaseHelper.addUser(email, password, name, address);
            if (isInserted) {
                Toast.makeText(AddUserActivity.this, "User added successfully", Toast.LENGTH_SHORT).show();
                finish(); // Close this activity and go back to ManageUsersActivity
            } else {
                Toast.makeText(AddUserActivity.this, "Error adding user", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
