package com.example.dogfoodapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;

import java.util.List;

public class ReviewPagerAdapter extends PagerAdapter {

    private Context context;
    private List<Review> reviews;

    public ReviewPagerAdapter(Context context, List<Review> reviews) {
        this.context = context;
        this.reviews = reviews;
    }

    @Override
    public int getCount() {
        return reviews.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_review, container, false);

        TextView userName = view.findViewById(R.id.reviewUserName);
        TextView reviewText = view.findViewById(R.id.reviewText);
        TextView reviewTimestamp = view.findViewById(R.id.reviewTimestamp);

        Review review = reviews.get(position);
        userName.setText(review.getUserName());
        reviewText.setText(review.getReviewText());
        reviewTimestamp.setText(formatTimestamp(review.getTimestamp()));

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    private String formatTimestamp(long timestamp) {
        // Convert the timestamp to a human-readable format, e.g., "2 hours ago"
        java.util.Date date = new java.util.Date(timestamp);
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMM dd, yyyy");
        return sdf.format(date);
    }
}
