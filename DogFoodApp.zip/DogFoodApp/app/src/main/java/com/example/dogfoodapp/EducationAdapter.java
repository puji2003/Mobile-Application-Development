package com.example.dogfoodapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EducationAdapter extends RecyclerView.Adapter<EducationAdapter.EducationViewHolder> {

    private List<EducationContent> educationContentList;

    public EducationAdapter(List<EducationContent> educationContentList) {
        this.educationContentList = educationContentList;
    }

    @NonNull
    @Override
    public EducationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_education_content, parent, false);
        return new EducationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EducationViewHolder holder, int position) {
        EducationContent content = educationContentList.get(position);
        holder.title.setText(content.getTitle());
        holder.description.setText(content.getDescription());
    }

    @Override
    public int getItemCount() {
        return educationContentList.size();
    }

    public static class EducationViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public TextView description;

        public EducationViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            description = itemView.findViewById(R.id.description);
        }
    }
}
