package com.example.dogfoodapp;

public class EducationContent {
    private String title;
    private String description;

    public EducationContent(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }
}
