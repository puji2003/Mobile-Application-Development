// OrderDatabaseHelper.java
package com.example.dogfoodapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class OrderDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "dogfood_orders.db";
    private static final int DATABASE_VERSION = 3; // Incremented for status addition

    private static final String TABLE_ORDERS = "orders";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_PRODUCT_NAME = "product_name";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_ORDER_DATE = "order_date";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_STATUS = "status";

    public OrderDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_ORDERS_TABLE = "CREATE TABLE " + TABLE_ORDERS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_PRODUCT_NAME + " TEXT,"
                + COLUMN_PRICE + " REAL,"
                + COLUMN_ORDER_DATE + " TEXT,"
                + COLUMN_USER_EMAIL + " TEXT,"
                + COLUMN_STATUS + " TEXT DEFAULT '" + Order.STATUS_PENDING + "'" + ")";
        db.execSQL(CREATE_ORDERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_ORDERS + " ADD COLUMN " + COLUMN_USER_EMAIL + " TEXT");
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE " + TABLE_ORDERS + " ADD COLUMN " + COLUMN_STATUS + " TEXT DEFAULT '" + Order.STATUS_PENDING + "'");
        }
    }

    public void addOrder(Order order, String userEmail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PRODUCT_NAME, order.getProductName());
        values.put(COLUMN_PRICE, order.getPrice());
        values.put(COLUMN_ORDER_DATE, order.getOrderDate());
        values.put(COLUMN_USER_EMAIL, userEmail);
        values.put(COLUMN_STATUS, order.getStatus());
        db.insert(TABLE_ORDERS, null, values);
        db.close();
    }

    public List<Order> getUserOrders(String userEmail) {
        List<Order> orderList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_ORDERS,
                null,
                COLUMN_USER_EMAIL + " = ?",
                new String[]{userEmail},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
                String productName = cursor.getString(cursor.getColumnIndex(COLUMN_PRODUCT_NAME));
                double price = cursor.getDouble(cursor.getColumnIndex(COLUMN_PRICE));
                String orderDate = cursor.getString(cursor.getColumnIndex(COLUMN_ORDER_DATE));
                String status = cursor.getString(cursor.getColumnIndex(COLUMN_STATUS));
                Order order = new Order(id, productName, price, orderDate, status);
                orderList.add(order);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return orderList;
    }

    public void updateOrderStatus(int orderId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_STATUS, status);
        db.update(TABLE_ORDERS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(orderId)});
    }

    public List<Order> getAllOrders() {
        List<Order> orderList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ORDERS, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID));
                String productName = cursor.getString(cursor.getColumnIndex(COLUMN_PRODUCT_NAME));
                double price = cursor.getDouble(cursor.getColumnIndex(COLUMN_PRICE));
                String orderDate = cursor.getString(cursor.getColumnIndex(COLUMN_ORDER_DATE));
                String status = cursor.getString(cursor.getColumnIndex(COLUMN_STATUS));
                Order order = new Order(id, productName, price, orderDate, status);
                orderList.add(order);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return orderList;
    }


}
