// OrderManagementActivity.java
package com.example.dogfoodapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class OrderManagementActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AdminOrderAdapter adminOrderAdapter;
    private OrderDatabaseHelper orderDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_management); // This should now resolve correctly

        recyclerView = findViewById(R.id.recycler_view_orders);
        orderDatabaseHelper = new OrderDatabaseHelper(this);

        List<Order> orderList = orderDatabaseHelper.getAllOrders();
        adminOrderAdapter = new AdminOrderAdapter(orderList, orderDatabaseHelper);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adminOrderAdapter);
    }
}
